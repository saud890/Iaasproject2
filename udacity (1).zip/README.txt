The files included are: 

index.html - The Index document for the website.
/assets - Bootssrap CSS framework, Font, and JavaScript libraries needed for the website to function.
/project.mobirise - Document files for the website.


